# Stock Sentiment Analysis
This project analyzes the sentiment of news headlines in order to make predictions of future movements.
print ("Stock Volatility Website")
